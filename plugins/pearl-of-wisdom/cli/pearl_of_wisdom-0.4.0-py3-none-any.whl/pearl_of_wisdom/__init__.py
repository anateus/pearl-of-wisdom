"""Pearl of Wisdom public package metadata."""

__version__ = "0.4.0"
