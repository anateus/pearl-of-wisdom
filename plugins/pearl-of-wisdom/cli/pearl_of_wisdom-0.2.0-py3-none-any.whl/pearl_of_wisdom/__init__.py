"""Pearl of Wisdom public package metadata."""

__version__ = "0.2.0"
